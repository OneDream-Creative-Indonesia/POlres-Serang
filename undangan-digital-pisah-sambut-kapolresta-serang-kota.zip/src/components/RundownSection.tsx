import React, { useState } from 'react';
import { Clock, CalendarDays, Award, UserCheck, Video, Gift, Music, Mic, BookOpen, Film, Landmark, Search } from 'lucide-react';
import { RUNDOWN_SCHEDULE } from '../types';

export const RundownSection: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSchedule = RUNDOWN_SCHEDULE.filter(
    (item) =>
      item.kegiatan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.keterangan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.waktu.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getIcon = (iconName?: string) => {
    switch (iconName) {
      case 'UserCheck': return <UserCheck className="w-4 h-4 text-[#ffd700]" />;
      case 'Mic': return <Mic className="w-4 h-4 text-[#ffd700]" />;
      case 'BookOpen': return <BookOpen className="w-4 h-4 text-[#ffd700]" />;
      case 'Video': return <Video className="w-4 h-4 text-[#ffd700]" />;
      case 'Award': return <Award className="w-4 h-4 text-[#ffd700]" />;
      case 'Landmark': return <Landmark className="w-4 h-4 text-[#ffd700]" />;
      case 'Film': return <Film className="w-4 h-4 text-[#ffd700]" />;
      case 'Gift': return <Gift className="w-4 h-4 text-[#ffd700]" />;
      case 'Music': return <Music className="w-4 h-4 text-[#ffd700]" />;
      default: return <Clock className="w-4 h-4 text-[#ffd700]" />;
    }
  };

  return (
    <section id="rundown" className="py-12 px-4 max-w-5xl mx-auto">
      {/* Container matching Page 3 of PDF */}
      <div className="relative rounded-3xl bg-gradient-to-b from-[#16171e]/98 via-[#0e0f14]/98 to-[#13141a]/98 border-2 border-[#d4af37]/60 shadow-[0_15px_40px_rgba(0,0,0,0.9)] p-6 sm:p-10 overflow-hidden">
        
        {/* Top Gold Border Ribbon */}
        <div className="absolute top-0 left-0 right-0 h-4 bg-gradient-to-r from-[#aa771c] via-[#ffd700] to-[#aa771c] opacity-80" />
        <div className="absolute bottom-0 left-0 right-0 h-4 bg-gradient-to-r from-[#aa771c] via-[#ffd700] to-[#aa771c] opacity-80" />

        <div className="relative z-10">
          {/* Header Title matching Page 3 */}
          <div className="text-center mb-8">
            <h2 className="font-cinzel text-2xl sm:text-3xl md:text-4xl font-black text-[#ffd700] tracking-wider drop-shadow-md">
              SUSUNAN ACARA PISAH SAMBUT
            </h2>
            <h3 className="font-cinzel text-xl sm:text-2xl md:text-3xl font-bold text-white tracking-widest mt-1">
              KAPOLRESTA SERANG KOTA
            </h3>

            {/* Sub-decorative divider */}
            <div className="flex items-center justify-center gap-2 mt-4 max-w-xs mx-auto">
              <div className="flex-1 h-[1px] bg-gradient-to-r from-transparent via-[#d4af37] to-[#d4af37]" />
              <CalendarDays className="w-4 h-4 text-[#ffd700]" />
              <div className="flex-1 h-[1px] bg-gradient-to-l from-transparent via-[#d4af37] to-[#d4af37]" />
            </div>

            <p className="text-xs sm:text-sm text-stone-300 mt-2">
              Kamis, 12 November 2026 • Ballroom Hotel Aston Serang
            </p>
          </div>

          {/* Quick Search / Filter Bar */}
          <div className="max-w-md mx-auto mb-6">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                type="text"
                placeholder="Cari sesi acara atau pengisi..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-black/60 border border-[#d4af37]/40 rounded-full text-xs sm:text-sm text-white placeholder-stone-400 focus:outline-none focus:border-[#ffd700] transition-colors"
              />
            </div>
          </div>

          {/* Desktop & Tablet Table matching exact visual grid in PDF Page 3 */}
          <div className="hidden md:block overflow-hidden rounded-xl border border-[#d4af37]/60 shadow-xl bg-black/40">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="bg-gradient-to-r from-[#201c10] via-[#332b12] to-[#201c10] border-b-2 border-[#d4af37]">
                  <th className="py-3.5 px-4 font-cinzel text-sm font-bold text-[#ffd700] tracking-wider w-1/4 text-center border-r border-[#d4af37]/40">
                    WAKTU
                  </th>
                  <th className="py-3.5 px-5 font-cinzel text-sm font-bold text-[#ffd700] tracking-wider w-2/5 text-center border-r border-[#d4af37]/40">
                    KEGIATAN
                  </th>
                  <th className="py-3.5 px-5 font-cinzel text-sm font-bold text-[#ffd700] tracking-wider w-1/3 text-center">
                    KET.
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredSchedule.map((item, index) => (
                  <tr
                    key={index}
                    className={`border-b border-[#d4af37]/25 transition-colors hover:bg-[#d4af37]/10 ${
                      index % 2 === 0 ? 'bg-black/30' : 'bg-stone-900/40'
                    }`}
                  >
                    <td className="py-3.5 px-4 font-mono text-xs sm:text-sm text-amber-200/90 font-semibold border-r border-[#d4af37]/30 text-center whitespace-nowrap">
                      {item.waktu}
                    </td>
                    <td className="py-3.5 px-5 border-r border-[#d4af37]/30">
                      <div className="flex items-center gap-2.5">
                        <div className="p-1 rounded bg-[#d4af37]/20 flex-shrink-0">
                          {getIcon(item.iconName)}
                        </div>
                        <span className="text-sm font-semibold text-white tracking-wide">
                          {item.kegiatan}
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-5 text-sm text-stone-300">
                      <span className="font-medium text-[#ffd700]/90">
                        {item.keterangan}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile View: Responsive Timeline / Cards */}
          <div className="block md:hidden space-y-3">
            {filteredSchedule.map((item, index) => (
              <div
                key={index}
                className="bg-black/60 border border-[#d4af37]/40 rounded-xl p-3.5 shadow-md relative overflow-hidden"
              >
                <div className="flex items-center justify-between gap-2 border-b border-[#d4af37]/20 pb-2 mb-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#ffd700] font-mono">
                    <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>{item.waktu}</span>
                  </div>
                  <div className="p-1 rounded bg-[#d4af37]/20">
                    {getIcon(item.iconName)}
                  </div>
                </div>

                <div className="text-sm font-bold text-white mb-1">
                  {item.kegiatan}
                </div>

                <div className="text-xs text-stone-300 flex items-start gap-1">
                  <span className="text-[#d4af37] font-semibold">Ket:</span>
                  <span className="text-stone-300">{item.keterangan}</span>
                </div>
              </div>
            ))}
          </div>

          {filteredSchedule.length === 0 && (
            <div className="text-center py-8 text-stone-400 text-sm">
              Tidak ada sesi yang cocok dengan kata kunci &quot;{searchTerm}&quot;
            </div>
          )}

          {/* Footer note matching solemn formality */}
          <div className="mt-8 text-center text-xs text-stone-400 italic">
            * Jadwal acara dapat disesuaikan dengan situasi dan protokol kedinasan pada hari H.
          </div>

        </div>
      </div>
    </section>
  );
};
