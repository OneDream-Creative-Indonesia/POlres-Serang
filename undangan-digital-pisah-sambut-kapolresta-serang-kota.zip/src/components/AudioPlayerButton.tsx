import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { audioPlayer } from '../utils/audio';

export const AudioPlayerButton: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  useEffect(() => {
    // Check initial state
    setIsPlaying(audioPlayer.getIsPlaying());
  }, []);

  const handleToggle = () => {
    const active = audioPlayer.toggle();
    setIsPlaying(active);
  };

  return (
    <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-40">
      <button
        onClick={handleToggle}
        type="button"
        className={`p-3 rounded-full shadow-2xl border transition-all duration-300 flex items-center gap-2 cursor-pointer ${
          isPlaying
            ? 'bg-[#ffd700] text-black border-[#aa771c] shadow-[0_0_20px_rgba(255,215,0,0.6)] animate-pulse'
            : 'bg-stone-900/90 text-stone-300 border-stone-700 hover:text-white hover:border-[#ffd700]'
        }`}
        title={isPlaying ? 'Matikan Musik' : 'Putar Musik Pengiring'}
      >
        {isPlaying ? (
          <>
            <Volume2 className="w-5 h-5 text-black" />
            <span className="text-xs font-bold text-black hidden sm:inline">Musik Aktif</span>
          </>
        ) : (
          <>
            <VolumeX className="w-5 h-5 text-stone-400" />
            <span className="text-xs text-stone-400 hidden sm:inline">Putar Musik</span>
          </>
        )}
      </button>
    </div>
  );
};
