import { EVENT_DETAILS } from '../types';

export function createGoogleCalendarUrl(): string {
  const title = encodeURIComponent(EVENT_DETAILS.title);
  const details = encodeURIComponent(
    `Pisah Sambut Kapolresta Serang Kota\nDari: ${EVENT_DETAILS.pejabatLama.name}\nKepada: ${EVENT_DETAILS.pejabatBaru.name}\n\nPakaian: ${EVENT_DETAILS.dressCode}\nRegistrasi: ${EVENT_DETAILS.registrationTime}`
  );
  const location = encodeURIComponent(`${EVENT_DETAILS.venue}, ${EVENT_DETAILS.address}`);
  // 12 Nov 2026 19:00 WIB (UTC+7) -> 12:00 UTC to 16:00 UTC
  const startTime = '20261112T120000Z';
  const endTime = '20261112T160000Z';

  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${startTime}/${endTime}&details=${details}&location=${location}`;
}

export function downloadIcsFile(): void {
  const icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Polresta Serang Kota//Pisah Sambut//ID',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    'UID:pisah-sambut-kapolresta-20261112@polrestaserangkota',
    'SUMMARY:' + EVENT_DETAILS.title,
    'DESCRIPTION:' + `Pisah Sambut Kapolresta Serang Kota\\nDari: ${EVENT_DETAILS.pejabatLama.name}\\nKepada: ${EVENT_DETAILS.pejabatBaru.name}\\nPakaian: ${EVENT_DETAILS.dressCode}`,
    'LOCATION:' + `${EVENT_DETAILS.venue}, ${EVENT_DETAILS.address}`,
    'DTSTART:20261112T120000Z',
    'DTEND:20261112T160000Z',
    'STATUS:CONFIRMED',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');

  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'Undangan-Pisah-Sambut-Kapolresta-Serang-Kota.ics';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
