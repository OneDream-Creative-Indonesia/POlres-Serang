import React, { useState, useEffect, useCallback } from 'react';
import { Lock, ArrowUp } from 'lucide-react';
import { Guest, INITIAL_GUESTS } from './types';
import { getGuestsApi } from './services/guestService';
import { OpeningEnvelope } from './components/OpeningEnvelope';
import { CoverSection } from './components/CoverSection';
import { EventDetailsSection } from './components/EventDetailsSection';
import { RundownSection } from './components/RundownSection';
import { LocationSection } from './components/LocationSection';
import { AudioPlayerButton } from './components/AudioPlayerButton';
import { BottomNavBar } from './components/BottomNavBar';
import { AdminPanel } from './components/AdminPanel';
import { OfficialLogos } from './components/OfficialLogos';

export default function App() {
  const [guests, setGuests] = useState<Guest[]>(INITIAL_GUESTS);
  const [activeGuest, setActiveGuest] = useState<Guest>(INITIAL_GUESTS[0]);
  const [isOpened, setIsOpened] = useState<boolean>(false);
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);
  const [activeSection, setActiveSection] = useState<string>('top');

  // Load guest list from backend API
  const refreshGuests = useCallback(async () => {
    try {
      const serverGuests = await getGuestsApi();
      if (serverGuests && serverGuests.length > 0) {
        setGuests(serverGuests);
        
        // Match active guest from URL query param ?to=...
        const urlParams = new URLSearchParams(window.location.search);
        const toParam = urlParams.get('to');
        if (toParam) {
          const match = serverGuests.find(
            (g) => g.name.toLowerCase() === toParam.toLowerCase()
          );
          if (match) {
            setActiveGuest(match);
          } else {
            setActiveGuest({
              id: 'custom_' + Date.now(),
              name: toParam,
              role: 'Tamu Undangan',
              slug: toParam.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
            });
          }
        } else {
          setActiveGuest(serverGuests[0]);
        }
      }
    } catch (err) {
      console.error('Failed to load guests from API', err);
    }
  }, []);

  useEffect(() => {
    refreshGuests();

    // Check if opened with admin param (e.g. ?admin=true or #admin)
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('admin') === 'true' || window.location.hash === '#admin') {
      setIsAdminOpen(true);
    }
  }, [refreshGuests]);

  // Handle URL change
  useEffect(() => {
    const handleUrlChange = () => {
      const urlParams = new URLSearchParams(window.location.search);
      const toParam = urlParams.get('to');
      if (toParam && guests.length > 0) {
        const found = guests.find(
          (g) => g.name.toLowerCase() === toParam.toLowerCase()
        );
        if (found) {
          setActiveGuest(found);
        } else {
          setActiveGuest({
            id: 'custom_' + Date.now(),
            name: toParam,
            role: 'Tamu Undangan',
            slug: toParam.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
          });
        }
      }
      if (urlParams.get('admin') === 'true' || window.location.hash === '#admin') {
        setIsAdminOpen(true);
      }
    };

    window.addEventListener('popstate', handleUrlChange);
    window.addEventListener('hashchange', handleUrlChange);
    return () => {
      window.removeEventListener('popstate', handleUrlChange);
      window.removeEventListener('hashchange', handleUrlChange);
    };
  }, [guests]);

  // Scroll spy for bottom nav
  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY + 200;
      const sections = ['top', 'acara', 'rundown', 'lokasi'];
      for (const sectionId of sections.reverse()) {
        const el = document.getElementById(sectionId);
        if (el && scrollPos >= el.offsetTop) {
          setActiveSection(sectionId);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSelectGuest = (guest: Guest) => {
    setActiveGuest(guest);
    const url = new URL(window.location.href);
    url.searchParams.set('to', guest.name);
    window.history.pushState({}, '', url.toString());
  };

  return (
    <div className="min-h-screen bg-[#0c0d10] text-stone-100 selection:bg-[#d4af37] selection:text-black pb-20 relative">
      
      {/* Global subtle corak ornament background layer with low opacity */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-[0.04] bg-repeat bg-center z-0"
        style={{ backgroundImage: `url('/assets/aistudio/corak_e60bcf32.png')`, backgroundSize: '320px' }}
      />

      <div className="relative z-10">
        {/* Opening Envelope Screen (visible initially until clicked) */}
        {!isOpened && (
          <OpeningEnvelope
            guestName={activeGuest.name}
            onOpen={() => setIsOpened(true)}
          />
        )}

      {/* Main Content Sections */}
      <main id="top">
        {/* Cover Section matching PDF Page 1 */}
        <CoverSection guestName={activeGuest.name} />

        {/* Event Details Section matching PDF Page 2 */}
        <EventDetailsSection />

        {/* Rundown Section matching PDF Page 3 */}
        <RundownSection />

        {/* Location & Navigation Section */}
        <LocationSection />
      </main>

      {/* Solemn Police Closing Footer */}
      <footer className="relative mt-16 border-t-2 border-[#d4af37]/40 bg-gradient-to-b from-[#121319] to-black py-12 px-4 text-center">
        <div className="max-w-2xl mx-auto space-y-4">
          <OfficialLogos size="md" className="mx-auto" />

          <h4 className="font-cinzel text-lg sm:text-xl font-bold text-[#ffd700]">
            KEPOLISIAN RESOR KOTA SERANG KOTA
          </h4>

          <p className="text-xs sm:text-sm text-stone-300 max-w-md mx-auto leading-relaxed">
            Merupakan suatu kehormatan dan kebahagiaan bagi kami apabila Bapak/Ibu berkenan hadir untuk memberikan doa restu.
          </p>

          <div className="w-24 h-[1px] bg-[#d4af37]/40 mx-auto my-3" />

          <p className="text-[11px] text-stone-400">
            Malam Pisah Sambut Kapolresta Serang Kota • Kamis, 12 November 2026 • Ballroom Hotel Aston Serang
          </p>

          {/* Quick links & Admin Access */}
          <div className="pt-3 flex flex-wrap items-center justify-center gap-4 text-xs text-stone-400">
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="inline-flex items-center gap-1.5 text-[#ffd700] hover:text-white transition-colors cursor-pointer"
            >
              <ArrowUp className="w-3.5 h-3.5" />
              <span>Kembali ke Atas</span>
            </button>

            <span>•</span>

            {/* Subtle organizer portal to manage guest backend */}
            <button
              onClick={() => setIsAdminOpen(true)}
              className="inline-flex items-center gap-1 text-stone-500 hover:text-[#ffd700] transition-colors cursor-pointer"
              title="Akses Panel Backend Pengelola Undangan"
            >
              <Lock className="w-3 h-3" />
              <span>Kelola Tamu (Admin)</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Floating Audio Toggle */}
      <AudioPlayerButton />

      {/* Mobile Bottom Navigation Bar */}
      <BottomNavBar activeSection={activeSection} />

      {/* Backend Admin Modal for Host / Organizer */}
      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        guests={guests}
        onRefreshGuests={refreshGuests}
        onSelectGuest={handleSelectGuest}
      />

      </div>
    </div>
  );
}
