import { Guest, INITIAL_GUESTS } from '../types';

const API_BASE = '/api/guests';

export async function getGuestsApi(): Promise<Guest[]> {
  try {
    const res = await fetch(API_BASE);
    if (!res.ok) {
      throw new Error(`HTTP error ${res.status}`);
    }
    const data = await res.json();
    if (Array.isArray(data) && data.length > 0) {
      localStorage.setItem('polresta_guests_cache', JSON.stringify(data));
      return data;
    }
    return INITIAL_GUESTS;
  } catch (err) {
    console.warn('Backend API unavailable, using local cache:', err);
    const cached = localStorage.getItem('polresta_guests_cache');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch {
        return INITIAL_GUESTS;
      }
    }
    return INITIAL_GUESTS;
  }
}

export async function addGuestApi(name: string, role: string = 'Tamu Undangan'): Promise<Guest> {
  try {
    const res = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, role }),
    });
    if (!res.ok) throw new Error('Failed to create guest on server');
    return await res.json();
  } catch (err) {
    console.warn('Creating guest locally:', err);
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const localGuest: Guest = {
      id: 'local_' + Date.now(),
      name: name.trim(),
      role,
      slug,
      createdAt: new Date().toISOString(),
    };
    return localGuest;
  }
}

export async function batchAddGuestsApi(names: string[]): Promise<Guest[]> {
  try {
    const res = await fetch(`${API_BASE}/batch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ names }),
    });
    if (!res.ok) throw new Error('Batch import failed on server');
    const data = await res.json();
    return data.added || [];
  } catch (err) {
    console.warn('Batch adding locally:', err);
    return names.map((name, idx) => ({
      id: 'local_' + Date.now() + '_' + idx,
      name: name.trim(),
      role: 'Tamu Undangan',
      slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      createdAt: new Date().toISOString(),
    }));
  }
}

export async function deleteGuestApi(id: string): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/${id}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch (err) {
    console.warn('Delete guest failed on server:', err);
    return true;
  }
}
