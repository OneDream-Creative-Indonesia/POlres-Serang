import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Ensure data folder and guests.json file exist in working directory or alongside server
const DATA_DIR = fs.existsSync(path.join(process.cwd(), 'data')) 
  ? path.join(process.cwd(), 'data')
  : path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'guests.json');

const INITIAL_GUESTS = [
  {
    id: 'guest_1',
    name: 'Ibu Vita',
    role: 'Tamu Kehormatan',
    slug: 'ibu-vita',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'guest_2',
    name: 'Bpk Fardhan Fauzan Nurfaizi & Ibu Fika',
    role: 'Tamu Kehormatan',
    slug: 'bpk-fardhan-fauzan-nurfaizi-ibu-fika',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'guest_3',
    name: 'Bpk Aditya Argobi',
    role: 'Tamu Kehormatan',
    slug: 'bpk-aditya-argobi',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'guest_4',
    name: 'Bpk Dharmawan',
    role: 'Tamu Kehormatan',
    slug: 'bpk-dharmawan',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'guest_5',
    name: 'Ibu Indira',
    role: 'Tamu Kehormatan',
    slug: 'ibu-indira',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'guest_6',
    name: 'Ibu Raisha Syarfuan',
    role: 'Tamu Kehormatan',
    slug: 'ibu-raisha-syarfuan',
    createdAt: new Date().toISOString(),
  },
];

function readGuests(): any[] {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DATA_FILE)) {
      fs.writeFileSync(DATA_FILE, JSON.stringify(INITIAL_GUESTS, null, 2), 'utf-8');
      return INITIAL_GUESTS;
    }
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading guests.json:', err);
    return INITIAL_GUESTS;
  }
}

function writeGuests(guests: any[]) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(guests, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing guests.json:', err);
  }
}

app.use(cors());
app.use(express.json());

// API Endpoints
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// GET all guests
app.get('/api/guests', (req, res) => {
  const guests = readGuests();
  res.json(guests);
});

// POST a new guest
app.post('/api/guests', (req, res) => {
  const { name, role } = req.body;
  if (!name || typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ error: 'Nama tamu wajib diisi' });
  }

  const cleanName = name.trim();
  const slug = cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  const guests = readGuests();

  const newGuest = {
    id: 'guest_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    name: cleanName,
    role: (role && String(role).trim()) || 'Tamu Undangan',
    slug: slug || 'tamu-' + Date.now(),
    createdAt: new Date().toISOString(),
  };

  guests.unshift(newGuest);
  writeGuests(guests);
  res.status(201).json(newGuest);
});

// POST batch guests (e.g., multiline text or array of names)
app.post('/api/guests/batch', (req, res) => {
  const { names } = req.body;
  if (!Array.isArray(names) || names.length === 0) {
    return res.status(400).json({ error: 'Daftar nama (array) wajib diisi' });
  }

  const guests = readGuests();
  const addedList: any[] = [];

  for (const item of names) {
    const rawName = typeof item === 'string' ? item : item?.name;
    if (rawName && typeof rawName === 'string' && rawName.trim()) {
      const cleanName = rawName.trim();
      const slug = cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      const newGuest = {
        id: 'guest_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        name: cleanName,
        role: typeof item === 'object' && item.role ? item.role : 'Tamu Undangan',
        slug: slug || 'tamu-' + Date.now(),
        createdAt: new Date().toISOString(),
      };
      guests.push(newGuest);
      addedList.push(newGuest);
    }
  }

  writeGuests(guests);
  res.status(201).json({ count: addedList.length, added: addedList });
});

// PUT update guest
app.put('/api/guests/:id', (req, res) => {
  const { id } = req.params;
  const { name, role } = req.body;
  const guests = readGuests();
  const index = guests.findIndex((g) => g.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Tamu tidak ditemukan' });
  }

  if (name) {
    guests[index].name = String(name).trim();
    guests[index].slug = guests[index].name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  }
  if (role) {
    guests[index].role = String(role).trim();
  }
  guests[index].updatedAt = new Date().toISOString();

  writeGuests(guests);
  res.json(guests[index]);
});

// DELETE a guest
app.delete('/api/guests/:id', (req, res) => {
  const { id } = req.params;
  const guests = readGuests();
  const filtered = guests.filter((g) => g.id !== id);

  if (filtered.length === guests.length) {
    return res.status(404).json({ error: 'Tamu tidak ditemukan' });
  }

  writeGuests(filtered);
  res.json({ success: true, id });
});

// Static assets / SPA setup
async function startServer() {
  if (!isProduction) {
    // In dev: mount Vite dev server middlewares
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: Number(PORT),
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In prod: serve built files from dist
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT} (${isProduction ? 'production' : 'development'})`);
  });
}

startServer();
