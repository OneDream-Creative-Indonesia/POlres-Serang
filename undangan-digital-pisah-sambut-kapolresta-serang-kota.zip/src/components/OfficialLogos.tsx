import React from 'react';

interface OfficialLogosProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const OfficialLogos: React.FC<OfficialLogosProps> = ({
  size = 'md',
  className = '',
}) => {
  const heightClasses = {
    sm: 'h-12 sm:h-14',
    md: 'h-16 sm:h-20',
    lg: 'h-20 sm:h-24',
  };

  const gapClasses = {
    sm: 'gap-3 sm:gap-4',
    md: 'gap-4 sm:gap-6',
    lg: 'gap-5 sm:gap-8',
  };

  return (
    <div className={`flex items-center justify-center ${gapClasses[size]} ${className}`}>
      {/* Tribrata National Police Crest (Golden) */}
      <div className="relative group transition-transform hover:scale-105 duration-300">
        <img
          src="/assets/aistudio/Insignia_of_the_Indonesian_National_Police.svg_952b9188.webp"
          alt="Lambang Tribrata Polri"
          className={`${heightClasses[size]} w-auto object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.85)] filter brightness-105`}
        />
      </div>

      {/* Official Polres Serang Kota Banten Badge */}
      <div className="relative group transition-transform hover:scale-105 duration-300">
        <img
          src="/assets/aistudio/LOGO_POLRES-Serang_455e4156.png"
          alt="Lambang Polres Serang Kota Banten"
          className={`${heightClasses[size]} w-auto object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.85)] filter brightness-105`}
        />
      </div>
    </div>
  );
};
