import React, { useState } from 'react';
import { MapPin, Navigation, ExternalLink, Check, Building } from 'lucide-react';
import { EVENT_DETAILS } from '../types';

export const LocationSection: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(`${EVENT_DETAILS.venue}, ${EVENT_DETAILS.address}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="lokasi" className="py-12 px-4 max-w-4xl mx-auto">
      <div className="relative rounded-3xl bg-gradient-to-b from-[#15161b] via-[#0e0f14] to-[#121319] border-2 border-[#d4af37]/60 shadow-[0_15px_40px_rgba(0,0,0,0.9)] p-6 sm:p-10 overflow-hidden">
        
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#d4af37]/15 border border-[#d4af37]/40 text-[#ffd700] text-xs font-semibold uppercase tracking-wider mb-2">
            <MapPin className="w-3.5 h-3.5" />
            <span>Lokasi Penyelenggaraan Acara</span>
          </div>
          <h2 className="font-cinzel text-2xl sm:text-3xl font-black text-white tracking-wider">
            TEMPAT & NAVIGASI
          </h2>
          <h3 className="font-serif text-lg sm:text-xl font-bold text-[#ffd700] mt-1">
            {EVENT_DETAILS.venue}
          </h3>
          <p className="text-xs sm:text-sm text-stone-300 max-w-lg mx-auto mt-2 leading-relaxed">
            {EVENT_DETAILS.address}
          </p>
        </div>

        {/* Embedded Interactive Map */}
        <div className="relative w-full h-72 sm:h-84 rounded-2xl overflow-hidden border border-[#d4af37]/50 shadow-2xl mb-6 bg-stone-900">
          <iframe
            title="Peta Lokasi Hotel Aston Serang"
            src="https://maps.google.com/maps?q=Hotel+Aston+Serang+Jalan+Raya+Syekh+Moh+Nawawi+Al-Bantani+No.29+Kota+Serang+Banten&t=&z=15&ie=UTF8&iwloc=&output=embed"
            className="w-full h-full border-0 filter contrast-105"
            loading="lazy"
            allowFullScreen
          />
          <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-[#d4af37]/50 text-[11px] text-[#ffd700] font-semibold flex items-center gap-1.5">
            <Building className="w-3.5 h-3.5" />
            <span>Aston Serang Hotel & Convention Center</span>
          </div>
        </div>

        {/* Action Buttons (Google Maps & Salin Alamat only) */}
        <div className="flex flex-wrap items-center justify-center gap-3">
          <a
            href={EVENT_DETAILS.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#aa771c] via-[#ffd700] to-[#b38728] text-black font-bold text-xs sm:text-sm flex items-center gap-2 hover:brightness-110 shadow-lg transition-all"
          >
            <Navigation className="w-4 h-4 text-black" />
            <span>Buka di Google Maps</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <button
            type="button"
            onClick={handleCopy}
            className="px-4 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700 text-xs sm:text-sm flex items-center gap-2 transition-colors cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400 font-semibold">Alamat Tersalin!</span>
              </>
            ) : (
              <span>Salin Alamat Lengkap</span>
            )}
          </button>
        </div>

      </div>
    </section>
  );
};
