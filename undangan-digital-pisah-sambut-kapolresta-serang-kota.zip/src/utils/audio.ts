/**
 * Web Audio API synthesizer for ceremonial ambient background music
 * Plays gentle traditional gamelan-gong / harp melodic harmony
 */
class CeremonialAudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private timer: number | null = null;
  private masterGain: GainNode | null = null;

  private initCtx() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.18, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Play a soft ceremonial chime/bell note with rich harmonics
  private playBell(freq: number, duration: number, delaySec: number) {
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime + delaySec;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);

    // Warm envelope
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.3, now + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    // Overtone oscillator
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(freq * 2.02, now);
    gain2.gain.setValueAtTime(0.0001, now);
    gain2.gain.exponentialRampToValueAtTime(0.08, now + 0.04);
    gain2.gain.exponentialRampToValueAtTime(0.0001, now + duration * 0.6);

    osc.connect(gain);
    osc2.connect(gain2);
    gain.connect(this.masterGain);
    gain2.connect(this.masterGain);

    osc.start(now);
    osc2.start(now);
    osc.stop(now + duration + 0.1);
    osc2.stop(now + duration + 0.1);
  }

  private playCeremonialChord() {
    if (!this.isPlaying) return;
    // Slendro / Pelog-inspired ceremonial regal chord sequence (D, F#, A, B, C#)
    const chords = [
      [293.66, 440.0, 587.33, 739.99], // D, A, D5, F#5
      [246.94, 369.99, 493.88, 659.25], // B, F#, B4, E5
      [329.63, 493.88, 659.25, 880.0],  // E, B, E5, A5
      [220.0, 329.63, 440.0, 554.37],   // A, E, A4, C#5
    ];

    const currentChordIndex = Math.floor((Date.now() / 3200) % chords.length);
    const chord = chords[currentChordIndex];

    chord.forEach((freq, idx) => {
      this.playBell(freq, 3.2, idx * 0.22);
    });
  }

  public play() {
    this.initCtx();
    this.isPlaying = true;
    this.playCeremonialChord();

    if (this.timer) clearInterval(this.timer);
    this.timer = window.setInterval(() => {
      if (this.isPlaying) {
        this.playCeremonialChord();
      }
    }, 3200);
  }

  public pause() {
    this.isPlaying = false;
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  public toggle(): boolean {
    if (this.isPlaying) {
      this.pause();
      return false;
    } else {
      this.play();
      return true;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const audioPlayer = new CeremonialAudioEngine();
