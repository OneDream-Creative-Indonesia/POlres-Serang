export interface Guest {
  id: string;
  name: string;
  role?: string;
  slug: string;
  phone?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface RundownItem {
  waktu: string;
  kegiatan: string;
  keterangan: string;
  penanggungJawab?: string;
  iconName?: string;
}

export const EVENT_DETAILS = {
  title: "PISAH SAMBUT KAPOLRESTA SERANG KOTA",
  subtitle: "Malam Pisah Sambut & Keakraban",
  dateFormatted: "Kamis, 12 November 2026",
  dateIso: "2026-11-12T19:00:00+07:00",
  time: "Pukul 19.00 WIB",
  registrationTime: "17.00 - 19.00 WIB",
  dressCode: "Bebas Rapi",
  venue: "BALLROOM HOTEL ASTON SERANG",
  address: "Jalan Raya Syekh Moh. Nawawi Al-Bantani No.29 Kota Serang - Banten 42171",
  mapsUrl: "https://maps.google.com/?q=Hotel+Aston+Serang+Jalan+Raya+Syekh+Moh+Nawawi+Al-Bantani+No.29+Kota+Serang+Banten",
  pejabatLama: {
    name: "Kombes Pol Yudha Satria, S.H., S.I.K., M.H.",
    title: "Kapolresta Serang Kota (Pejabat Lama)",
  },
  pejabatBaru: {
    name: "Kombes Pol Guntur Muhammad Tariq, S.I.K., M.Si.",
    title: "Kapolresta Serang Kota (Pejabat Baru)",
  },
};

export const INITIAL_GUESTS: Guest[] = [
  {
    id: "guest_1",
    name: "Ibu Vita",
    role: "Tamu Kehormatan",
    slug: "ibu-vita",
  },
  {
    id: "guest_2",
    name: "Bpk Fardhan Fauzan Nurfaizi & Ibu Fika",
    role: "Tamu Kehormatan",
    slug: "bpk-fardhan-fauzan-nurfaizi-ibu-fika",
  },
  {
    id: "guest_3",
    name: "Bpk Aditya Argobi",
    role: "Tamu Kehormatan",
    slug: "bpk-aditya-argobi",
  },
  {
    id: "guest_4",
    name: "Bpk Dharmawan",
    role: "Tamu Kehormatan",
    slug: "bpk-dharmawan",
  },
  {
    id: "guest_5",
    name: "Ibu Indira",
    role: "Tamu Kehormatan",
    slug: "ibu-indira",
  },
  {
    id: "guest_6",
    name: "Ibu Raisha Syarfuan",
    role: "Tamu Kehormatan",
    slug: "ibu-raisha-syarfuan",
  },
];

export const RUNDOWN_SCHEDULE: RundownItem[] = [
  {
    waktu: "17.00 WIB - 19.00 WIB",
    kegiatan: "Registrasi Undangan",
    keterangan: "Dihadiri oleh PJU & Tamu Undangan",
    iconName: "UserCheck",
  },
  {
    waktu: "19.00 WIB - 19.05 WIB",
    kegiatan: "Pembukaan",
    keterangan: "MC",
    iconName: "Mic",
  },
  {
    waktu: "19.05 WIB - 19.10 WIB",
    kegiatan: "Pembacaan Do’a",
    keterangan: "Ketua MUI Kota Serang",
    iconName: "BookOpen",
  },
  {
    waktu: "19.10 WIB - 19.20 WIB",
    kegiatan: "Penayangan Video Kilas Balik Kapolres Baru",
    keterangan: "Tim IT POLRESTA SERANG KOTA",
    iconName: "Video",
  },
  {
    waktu: "19.20 WIB - 19.30 WIB",
    kegiatan: "Sambutan Pejabat Baru",
    keterangan: "Kombes Pol Guntur Muhammad Tariq, S.I.K., M.Si.",
    iconName: "Award",
  },
  {
    waktu: "19.30 WIB - 19.40 WIB",
    kegiatan: "Sambutan Walikota Serang",
    keterangan: "H. Budi Rustandi, S.E.",
    iconName: "Landmark",
  },
  {
    waktu: "19.40 WIB - 19.50 WIB",
    kegiatan: "Penayangan Video Kilas Balik Kapolresta Lama",
    keterangan: "Tim IT POLRESTA SERANG KOTA",
    iconName: "Film",
  },
  {
    waktu: "19.50 WIB - 20.00 WIB",
    kegiatan: "Sambutan Pejabat Lama",
    keterangan: "Kombes Pol Yudha Satria, S.H., S.I.K., M.H.",
    iconName: "Award",
  },
  {
    waktu: "20.00 WIB - 20.15 WIB",
    kegiatan: "Pemberian Cendra mata",
    keterangan: "Ibu - ibu BHAYANGKARI",
    iconName: "Gift",
  },
  {
    waktu: "20.15 WIB",
    kegiatan: "Ramah Tamah & Hiburan",
    keterangan: "LIVE BAND",
    iconName: "Music",
  },
];
