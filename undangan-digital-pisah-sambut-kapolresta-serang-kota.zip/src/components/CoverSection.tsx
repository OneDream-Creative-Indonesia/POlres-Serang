import React from 'react';
import { ChevronDown, UserCheck } from 'lucide-react';
import { EVENT_DETAILS } from '../types';
import { OfficialLogos } from './OfficialLogos';

interface CoverSectionProps {
  guestName: string;
}

export const CoverSection: React.FC<CoverSectionProps> = ({ guestName }) => {
  return (
    <section className="relative min-h-[90vh] flex flex-col items-center justify-between py-12 px-4 text-center overflow-hidden">
      
      {/* Background with authentic building photo */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-35 mix-blend-luminosity scale-100"
        style={{ backgroundImage: `url('/assets/aistudio/unnamed__2__fcd91e85.webp')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/85 via-black/70 to-[#0c0d10]" />

      {/* Top subtle badge */}
      <div className="relative z-10 w-full max-w-4xl flex items-center justify-center pb-2">
        <span className="text-[11px] sm:text-xs text-[#d4af37] font-semibold tracking-widest uppercase bg-black/60 px-4 py-1.5 rounded-full border border-[#d4af37]/40">
          POLRESTA SERANG KOTA
        </span>
      </div>

      {/* Center Main Invitation Frame matching PDF Page 1 */}
      <div className="relative z-10 w-full max-w-2xl mx-auto my-auto py-6">
        
        {/* Badges with new official logos */}
        <OfficialLogos size="lg" className="mb-4" />

        {/* Title */}
        <p className="font-cinzel text-2xl sm:text-3xl text-[#d4af37] font-semibold tracking-wider">
          Undangan
        </p>
        <h1 className="font-cinzel text-3xl sm:text-5xl font-black text-white tracking-wider mt-2 drop-shadow-lg">
          PISAH SAMBUT
        </h1>
        <h2 className="font-cinzel text-2xl sm:text-4xl font-black text-gold-gradient tracking-widest mt-1 drop-shadow-md">
          KAPOLRESTA SERANG KOTA
        </h2>

        {/* Golden Separator */}
        <div className="w-32 h-[2px] bg-gradient-to-r from-transparent via-[#ffd700] to-transparent my-6 mx-auto" />

        {/* Personalized Guest Plate matching PDF */}
        <div className="w-full max-w-md mx-auto my-4">
          <p className="text-xs sm:text-sm text-[#e5c158] italic mb-2 tracking-wide font-medium">
            Kepada Yth Bapak/Ibu/Saudara/i
          </p>

          <div className="relative border-2 border-[#d4af37] rounded-xl p-4 sm:p-5 bg-black/70 shadow-[0_0_25px_rgba(212,175,55,0.3)] backdrop-blur-md">
            {/* Corner ornaments */}
            <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-[#ffd700]" />
            <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-[#ffd700]" />
            <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-[#ffd700]" />
            <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-[#ffd700]" />

            <div className="flex items-center justify-center gap-2">
              <UserCheck className="w-4 h-4 text-[#ffd700] flex-shrink-0" />
              <p className="text-lg sm:text-2xl font-bold text-white tracking-wide">
                {guestName}
              </p>
            </div>
          </div>

          <p className="text-[11px] sm:text-xs text-stone-400 mt-2.5 italic">
            Maaf apabila ada kesalahan dalam penulisan nama/gelar
          </p>
        </div>

        {/* Quick event meta */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-xs sm:text-sm text-stone-300">
          <span className="font-semibold text-[#ffd700]">{EVENT_DETAILS.dateFormatted}</span>
          <span>•</span>
          <span>{EVENT_DETAILS.time}</span>
          <span>•</span>
          <span className="font-semibold text-white">{EVENT_DETAILS.venue}</span>
        </div>

        {/* Scroll down prompt */}
        <div className="mt-8">
          <a
            href="#acara"
            className="inline-flex flex-col items-center gap-1 text-xs text-[#ffd700] hover:text-white transition-colors cursor-pointer group"
          >
            <span className="uppercase tracking-widest text-[10px] font-semibold">Rincian Acara</span>
            <ChevronDown className="w-5 h-5 animate-bounce group-hover:scale-110" />
          </a>
        </div>

      </div>

      {/* Bottom Batik Ornament Border matching PDF */}
      <div className="relative z-10 w-full max-w-4xl pt-4">
        <img 
          src="/pdf-pages/batik_border_clean.png" 
          alt="Batik Border Polresta" 
          className="w-full h-5 sm:h-6 object-cover rounded opacity-80"
        />
      </div>

    </section>
  );
};
