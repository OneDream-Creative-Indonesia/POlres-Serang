import React from 'react';
import { Mail, Sparkles, UserCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { audioPlayer } from '../utils/audio';
import { OfficialLogos } from './OfficialLogos';

interface OpeningEnvelopeProps {
  guestName: string;
  onOpen: () => void;
}

export const OpeningEnvelope: React.FC<OpeningEnvelopeProps> = ({
  guestName,
  onOpen,
}) => {
  const handleOpenClick = () => {
    // Fire celebratory gold confetti
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.75 },
      colors: ['#D4AF37', '#FFD700', '#F3E5AB', '#ffffff'],
    });

    // Start ceremonial ambient audio
    try {
      audioPlayer.play();
    } catch {
      // Audio autoplay restrictions gracefully handled
    }

    onOpen();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black overflow-hidden px-4">
      {/* Background with authentic building photo */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-40 scale-105 transition-transform duration-1000 ease-out"
        style={{ backgroundImage: `url('/assets/aistudio/unnamed__2__fcd91e85.webp')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/85 to-black/70" />

      {/* Floating particles or luxury subtle radial glow */}
      <div className="absolute w-[500px] h-[500px] bg-yellow-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Card container styled exactly as PDF Page 1 */}
      <div className="relative z-10 w-full max-w-lg mx-auto bg-gradient-to-b from-[#18191f]/95 to-[#0d0e13]/98 border border-[#d4af37]/60 rounded-2xl shadow-2xl p-6 sm:p-8 text-center backdrop-blur-md flex flex-col items-center">
        
        {/* Top Badges / Emblems with new official logos */}
        <OfficialLogos size="md" className="mb-3" />

        {/* Title Block matching PDF Page 1 */}
        <p className="font-cinzel text-xl sm:text-2xl text-[#d4af37] font-semibold tracking-wider">
          Undangan
        </p>
        <h1 className="font-cinzel text-2xl sm:text-3xl font-extrabold text-white tracking-wide mt-1">
          PISAH SAMBUT
        </h1>
        <h2 className="font-cinzel text-xl sm:text-2xl font-black text-gold-gradient tracking-wider mt-1 drop-shadow-md">
          KAPOLRESTA SERANG KOTA
        </h2>

        {/* Golden Separator */}
        <div className="w-24 h-[2px] bg-gradient-to-r from-transparent via-[#d4af37] to-transparent my-4" />

        {/* Recipient Frame matching the exact box in PDF Page 1 */}
        <div className="w-full my-2">
          <p className="text-xs sm:text-sm text-[#e5c158] italic mb-2 tracking-wide font-medium">
            Kepada Yth Bapak/Ibu/Saudara/i
          </p>

          <div className="relative mx-auto max-w-sm border-2 border-[#d4af37] rounded-lg p-4 bg-black/60 shadow-[0_0_15px_rgba(212,175,55,0.25)] backdrop-blur-sm group hover:border-[#ffd700] transition-all">
            {/* Corner ornaments */}
            <div className="absolute -top-1 -left-1 w-2.5 h-2.5 border-t-2 border-l-2 border-[#ffd700]" />
            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 border-t-2 border-r-2 border-[#ffd700]" />
            <div className="absolute -bottom-1 -left-1 w-2.5 h-2.5 border-b-2 border-l-2 border-[#ffd700]" />
            <div className="absolute -bottom-1 -right-1 w-2.5 h-2.5 border-b-2 border-r-2 border-[#ffd700]" />

            <div className="flex items-center justify-center gap-2">
              <UserCheck className="w-4 h-4 text-[#d4af37] flex-shrink-0" />
              <p className="text-base sm:text-lg font-bold text-white tracking-wide leading-tight">
                {guestName || "Tamu Undangan"}
              </p>
            </div>
          </div>

          <p className="text-[11px] sm:text-xs text-stone-400 mt-2 italic">
            Maaf apabila ada kesalahan dalam penulisan nama/gelar
          </p>
        </div>

        {/* Open Button with Interactive Glow */}
        <div className="mt-6 flex flex-col items-center gap-3 w-full max-w-xs">
          <button
            onClick={handleOpenClick}
            className="w-full relative group overflow-hidden py-3.5 px-6 rounded-full bg-gradient-to-r from-[#aa771c] via-[#ffd700] to-[#b38728] text-black font-bold text-sm sm:text-base tracking-wider uppercase shadow-[0_0_20px_rgba(212,175,55,0.5)] hover:shadow-[0_0_30px_rgba(255,215,0,0.8)] transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Mail className="w-5 h-5 text-black group-hover:scale-110 transition-transform" />
            <span>Buka Undangan</span>
            <Sparkles className="w-4 h-4 text-black group-hover:rotate-12 transition-transform" />
          </button>
        </div>

        {/* Bottom Batik Ornament Border matching PDF Page 1 */}
        <div className="w-full mt-6 pt-2 border-t border-[#d4af37]/30">
          <img 
            src="/pdf-pages/batik_border_clean.png" 
            alt="Batik Border" 
            className="w-full h-4 sm:h-5 object-cover rounded opacity-80"
          />
        </div>
      </div>
    </div>
  );
};
