import React, { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, Shirt, CalendarPlus, Navigation, ExternalLink, Check } from 'lucide-react';
import { EVENT_DETAILS } from '../types';
import { createGoogleCalendarUrl, downloadIcsFile } from '../utils/calendar';
import { OfficialLogos } from './OfficialLogos';

export const EventDetailsSection: React.FC = () => {
  const [calendarMenuOpen, setCalendarMenuOpen] = useState(false);
  const [copiedAddress, setCopiedAddress] = useState(false);

  // Countdown timer to event date (Nov 12, 2026 19:00 WIB = 12:00 UTC)
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const targetDate = new Date('2026-11-12T19:00:00+07:00').getTime();

    const updateCountdown = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      } else {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);
        setTimeLeft({ days, hours, minutes, seconds });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  const copyAddress = () => {
    navigator.clipboard.writeText(`${EVENT_DETAILS.venue}, ${EVENT_DETAILS.address}`);
    setCopiedAddress(true);
    setTimeout(() => setCopiedAddress(false), 2500);
  };

  return (
    <section id="acara" className="relative py-12 px-4 max-w-4xl mx-auto">
      {/* Background Frame Styled identically to Page 2 of PDF with curved gold arches */}
      <div className="relative rounded-3xl bg-gradient-to-b from-[#16171e]/98 via-[#0e0f14]/98 to-[#13141a]/98 border-2 border-[#d4af37]/60 shadow-[0_15px_40px_rgba(0,0,0,0.9)] p-6 sm:p-10 overflow-hidden">
        
        {/* Top Gold Curved Arch Graphic Accent */}
        <div className="absolute top-0 left-0 right-0 h-4 bg-gradient-to-r from-[#aa771c] via-[#ffd700] to-[#aa771c] opacity-80" />
        <div className="absolute bottom-0 left-0 right-0 h-4 bg-gradient-to-r from-[#aa771c] via-[#ffd700] to-[#aa771c] opacity-80" />

        <div className="relative z-10 flex flex-col items-center text-center">
          
          {/* Official Police Insignias with new official logos */}
          <OfficialLogos size="md" className="mb-4" />

          {/* Invitation Greeting matching PDF */}
          <p className="text-sm sm:text-base text-stone-200 max-w-md mx-auto leading-relaxed font-medium">
            Dengan hormat kami mengundang Bapak/Ibu/Saudara/i untuk<br />
            <span className="text-[#ffd700] font-semibold">Menghadiri acara:</span>
          </p>

          {/* Main Title matching Page 2 */}
          <h2 className="font-cinzel text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-wider mt-4">
            PISAH SAMBUT
          </h2>
          <h3 className="font-cinzel text-xl sm:text-2xl md:text-3xl font-extrabold text-gold-gradient tracking-widest mt-1">
            KAPOLRESTA SERANG KOTA
          </h3>

          {/* Golden Diamond Divider matching PDF Page 2 */}
          <div className="flex items-center justify-center gap-3 my-6 w-full max-w-md">
            <div className="flex-1 h-[1.5px] bg-gradient-to-r from-transparent via-[#d4af37] to-[#d4af37]" />
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rotate-45 bg-[#ffd700]" />
              <span className="w-2.5 h-2.5 rotate-45 bg-[#ffd700] ring-2 ring-[#aa771c]" />
              <span className="w-1.5 h-1.5 rotate-45 bg-[#ffd700]" />
            </div>
            <div className="flex-1 h-[1.5px] bg-gradient-to-l from-transparent via-[#d4af37] to-[#d4af37]" />
          </div>

          {/* Officials Showcase */}
          <div className="w-full max-w-2xl bg-black/40 border border-[#d4af37]/30 rounded-2xl p-5 sm:p-7 backdrop-blur-sm my-2">
            {/* Pejabat Lama */}
            <div className="group">
              <span className="text-[11px] uppercase tracking-widest text-[#d4af37]/80 font-bold block mb-1">
                Pejabat Lama
              </span>
              <h4 className="font-playfair text-xl sm:text-2xl md:text-3xl font-bold text-[#ffd700] tracking-wide group-hover:text-white transition-colors">
                {EVENT_DETAILS.pejabatLama.name}
              </h4>
            </div>

            {/* "Kepada" Divider */}
            <div className="my-3 flex items-center justify-center gap-3">
              <div className="w-12 h-[1px] bg-[#d4af37]/40" />
              <span className="text-sm sm:text-base italic font-serif text-stone-300 font-semibold px-2">
                Kepada
              </span>
              <div className="w-12 h-[1px] bg-[#d4af37]/40" />
            </div>

            {/* Pejabat Baru */}
            <div className="group">
              <span className="text-[11px] uppercase tracking-widest text-[#d4af37]/80 font-bold block mb-1">
                Pejabat Baru
              </span>
              <h4 className="font-playfair text-xl sm:text-2xl md:text-3xl font-bold text-[#ffd700] tracking-wide group-hover:text-white transition-colors">
                {EVENT_DETAILS.pejabatBaru.name}
              </h4>
            </div>
          </div>

          {/* Date, Time & Venue Block matching PDF */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl mt-6">
            
            {/* Time Card */}
            <div className="bg-[#1a1b22]/80 border border-[#d4af37]/40 rounded-xl p-4 text-center hover:border-[#ffd700] transition-colors">
              <div className="w-9 h-9 mx-auto rounded-full bg-[#d4af37]/15 border border-[#d4af37]/40 flex items-center justify-center mb-2">
                <Calendar className="w-4 h-4 text-[#ffd700]" />
              </div>
              <p className="font-bold text-white text-base sm:text-lg">
                {EVENT_DETAILS.dateFormatted}
              </p>
              <div className="flex items-center justify-center gap-1.5 text-stone-300 text-sm mt-1">
                <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>{EVENT_DETAILS.time}</span>
              </div>
              <p className="text-xs text-[#e5c158] mt-1 font-medium">
                Registrasi: {EVENT_DETAILS.registrationTime}
              </p>
            </div>

            {/* Dress code & Venue Card */}
            <div className="bg-[#1a1b22]/80 border border-[#d4af37]/40 rounded-xl p-4 text-center hover:border-[#ffd700] transition-colors">
              <div className="w-9 h-9 mx-auto rounded-full bg-[#d4af37]/15 border border-[#d4af37]/40 flex items-center justify-center mb-2">
                <Shirt className="w-4 h-4 text-[#ffd700]" />
              </div>
              <p className="text-xs uppercase tracking-wider text-[#d4af37] font-semibold">
                Ketentuan Pakaian
              </p>
              <p className="font-bold text-white text-base sm:text-lg mt-0.5">
                {EVENT_DETAILS.dressCode}
              </p>
              <p className="text-xs text-stone-300 mt-1">
                Formal / Batik / PDU yang ditentukan
              </p>
            </div>
          </div>

          {/* Venue Details */}
          <div className="w-full max-w-2xl bg-black/60 border border-[#d4af37]/50 rounded-2xl p-5 mt-4 text-center">
            <div className="flex items-center justify-center gap-2 text-[#ffd700] mb-1">
              <MapPin className="w-5 h-5 flex-shrink-0 animate-bounce" />
              <h5 className="font-cinzel text-lg sm:text-xl font-bold tracking-wide">
                {EVENT_DETAILS.venue}
              </h5>
            </div>
            <p className="text-xs sm:text-sm text-stone-300 max-w-lg mx-auto leading-relaxed">
              {EVENT_DETAILS.address}
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3 mt-4">
              <a
                href={EVENT_DETAILS.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-[#aa771c] to-[#d4af37] text-black font-semibold text-xs sm:text-sm hover:brightness-110 shadow-md transition-all"
              >
                <Navigation className="w-4 h-4" />
                <span>Petunjuk Arah Google Maps</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <button
                type="button"
                onClick={copyAddress}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm border border-stone-600 transition-colors cursor-pointer"
              >
                {copiedAddress ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">Alamat Disalin!</span>
                  </>
                ) : (
                  <span>Salin Alamat</span>
                )}
              </button>
            </div>
          </div>

          {/* Countdown Clock */}
          <div className="w-full max-w-2xl mt-8 pt-6 border-t border-[#d4af37]/30">
            <p className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold mb-3">
              Menghitung Waktu Menuju Acara
            </p>
            <div className="grid grid-cols-4 gap-2 sm:gap-4 max-w-md mx-auto">
              {[
                { label: 'Hari', value: timeLeft.days },
                { label: 'Jam', value: timeLeft.hours },
                { label: 'Menit', value: timeLeft.minutes },
                { label: 'Detik', value: timeLeft.seconds },
              ].map((item, idx) => (
                <div 
                  key={idx} 
                  className="bg-black/70 border border-[#d4af37]/40 rounded-xl p-2 sm:p-3 shadow-inner"
                >
                  <span className="block font-cinzel text-xl sm:text-3xl font-extrabold text-[#ffd700]">
                    {String(item.value).padStart(2, '0')}
                  </span>
                  <span className="text-[10px] sm:text-xs text-stone-400 uppercase tracking-wider">
                    {item.label}
                  </span>
                </div>
              ))}
            </div>

            {/* Add to Calendar Button */}
            <div className="relative mt-5 inline-block">
              <button
                type="button"
                onClick={() => setCalendarMenuOpen(!calendarMenuOpen)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-[#d4af37] bg-black/60 hover:bg-[#d4af37]/20 text-[#ffd700] text-xs sm:text-sm font-semibold transition-all cursor-pointer"
              >
                <CalendarPlus className="w-4 h-4" />
                <span>Simpan ke Kalender Anda</span>
              </button>

              {calendarMenuOpen && (
                <div className="absolute left-1/2 -translate-x-1/2 mt-2 w-56 bg-[#18191f] border border-[#d4af37] rounded-xl shadow-2xl p-2 z-20 text-left">
                  <a
                    href={createGoogleCalendarUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block px-3 py-2 text-xs sm:text-sm text-stone-200 hover:bg-[#d4af37]/20 rounded-lg transition-colors"
                  >
                    📅 Google Calendar
                  </a>
                  <button
                    type="button"
                    onClick={() => {
                      downloadIcsFile();
                      setCalendarMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs sm:text-sm text-stone-200 hover:bg-[#d4af37]/20 rounded-lg transition-colors cursor-pointer"
                  >
                    🍎 Apple / Outlook (.ics)
                  </button>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
