import React, { useState } from 'react';
import { 
  X, Plus, Search, Copy, Check, MessageCircle, QrCode, Trash2, 
  ExternalLink, Server, Download, Upload, RefreshCw, FileSpreadsheet, Lock, LogOut, ShieldAlert
} from 'lucide-react';
import QRCode from 'qrcode';
import { Guest, EVENT_DETAILS } from '../types';
import { addGuestApi, batchAddGuestsApi, deleteGuestApi } from '../services/guestService';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  guests: Guest[];
  onRefreshGuests: () => void;
  onSelectGuest: (guest: Guest) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  guests,
  onRefreshGuests,
  onSelectGuest,
}) => {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('polresta_admin_auth') === 'true';
  });
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');

  // Dashboard state
  const [activeTab, setActiveTab] = useState<'guests' | 'batch'>('guests');
  const [search, setSearch] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState('Tamu Kehormatan');
  const [batchText, setBatchText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [allCopied, setAllCopied] = useState(false);
  const [qrModal, setQrModal] = useState<{ guest: Guest; qrUrl: string } | null>(null);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const email = emailInput.trim().toLowerCase();
    const password = passwordInput.trim();

    if (email === 'admin@gmail.com' && password === 'Rahasia123') {
      setIsAuthenticated(true);
      sessionStorage.setItem('polresta_admin_auth', 'true');
      setLoginError('');
      setEmailInput('');
      setPasswordInput('');
    } else {
      setLoginError('Email atau kata sandi tidak sesuai. Silakan coba lagi.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('polresta_admin_auth');
  };

  const getGuestUrl = (guest: Guest): string => {
    const origin = window.location.origin;
    const path = window.location.pathname;
    const url = new URL(origin + path);
    url.searchParams.set('to', guest.name);
    return url.toString();
  };

  const getWhatsAppMessage = (guest: Guest): string => {
    const url = getGuestUrl(guest);
    return `Kepada Yth.
*${guest.name}*
di Tempat

Assalamu’alaikum Warahmatullahi Wabarakatuh / Salam Sejahtera,

Tanpa mengurangi rasa hormat, kami bermaksud mengundang Bapak/Ibu/Saudara/i untuk berkenan menghadiri acara:

*${EVENT_DETAILS.title}*
Dari: ${EVENT_DETAILS.pejabatLama.name}
Kepada: ${EVENT_DETAILS.pejabatBaru.name}

🗓 *Hari / Tanggal:* ${EVENT_DETAILS.dateFormatted}
⏰ *Waktu:* ${EVENT_DETAILS.time} (Registrasi ${EVENT_DETAILS.registrationTime})
📍 *Tempat:* ${EVENT_DETAILS.venue}
(${EVENT_DETAILS.address})
👔 *Pakaian:* ${EVENT_DETAILS.dressCode}

Untuk melihat rincian undangan resmi secara digital, silakan klik tautan di bawah ini:
👉 ${url}

Merupakan suatu kehormatan dan kebahagiaan bagi kami apabila Bapak/Ibu berkenan hadir untuk memberikan doa restu.

Terima kasih.
Hormat kami,
*Panitia Pisah Sambut Kapolresta Serang Kota*`;
  };

  const handleCopyLink = (guest: Guest) => {
    const url = getGuestUrl(guest);
    navigator.clipboard.writeText(url);
    setCopiedId(guest.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleShareWhatsApp = (guest: Guest) => {
    const message = getWhatsAppMessage(guest);
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleShowQr = async (guest: Guest) => {
    const url = getGuestUrl(guest);
    try {
      const qrUrl = await QRCode.toDataURL(url, {
        width: 300,
        margin: 2,
        color: { dark: '#0e0f14', light: '#ffffff' },
      });
      setQrModal({ guest, qrUrl });
    } catch (err) {
      console.error('Failed to generate QR', err);
    }
  };

  const handleAddSingle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    setIsSubmitting(true);
    try {
      await addGuestApi(newName.trim(), newRole.trim());
      setNewName('');
      onRefreshGuests();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleBatchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!batchText.trim()) return;
    const names = batchText
      .split('\n')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    if (names.length === 0) return;
    setIsSubmitting(true);
    try {
      await batchAddGuestsApi(names);
      setBatchText('');
      setActiveTab('guests');
      onRefreshGuests();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (confirm(`Hapus tamu "${name}" dari daftar undangan?`)) {
      await deleteGuestApi(id);
      onRefreshGuests();
    }
  };

  const handleCopyAll = () => {
    const lines = guests.map((g) => `• ${g.name}\n  ${getGuestUrl(g)}`).join('\n\n');
    navigator.clipboard.writeText(`DAFTAR TAUTAN UNDANGAN POLRESTA SERANG KOTA:\n\n${lines}`);
    setAllCopied(true);
    setTimeout(() => setAllCopied(false), 3000);
  };

  const handleExportCsv = () => {
    const rows = [
      ['No', 'Nama Tamu', 'Kategori / Peran', 'Tautan Undangan Digital'],
      ...guests.map((g, idx) => [idx + 1, g.name, g.role || 'Tamu Undangan', getGuestUrl(g)]),
    ];
    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.map((val) => `"${val}"`).join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Daftar_Tamu_Undangan_Polresta_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredGuests = guests.filter((g) =>
    g.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-3 sm:p-6 overflow-y-auto">
      
      {/* Login Screen (If Not Authenticated) */}
      {!isAuthenticated ? (
        <div className="relative w-full max-w-md bg-[#14151a] border-2 border-[#d4af37] rounded-2xl shadow-2xl p-6 sm:p-8 text-center my-6">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-lg bg-black/40 hover:bg-stone-800 text-stone-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 mx-auto rounded-full bg-[#d4af37]/15 border border-[#d4af37]/60 flex items-center justify-center mb-4">
            <Lock className="w-6 h-6 text-[#ffd700]" />
          </div>

          <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-white tracking-wide">
            Akses Panel Kelola Tamu
          </h3>
          <p className="text-xs text-stone-300 mt-1 mb-6">
            Masukkan akun administrator untuk mengelola daftar tamu undangan
          </p>

          <form onSubmit={handleLogin} className="space-y-4 text-left">
            <div>
              <label className="block text-xs font-bold text-[#ffd700] uppercase tracking-wider mb-1">
                Email
              </label>
              <input
                type="email"
                required
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                placeholder="admin@gmail.com"
                className="w-full px-3.5 py-2.5 rounded-lg bg-black/60 border border-stone-700 text-white text-sm focus:outline-none focus:border-[#ffd700]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#ffd700] uppercase tracking-wider mb-1">
                Kata Sandi
              </label>
              <input
                type="password"
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Masukkan kata sandi..."
                className="w-full px-3.5 py-2.5 rounded-lg bg-black/60 border border-stone-700 text-white text-sm focus:outline-none focus:border-[#ffd700]"
              />
            </div>

            {loginError && (
              <div className="p-3 rounded-lg bg-rose-950/80 border border-rose-500 text-rose-200 text-xs flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400 flex-shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 rounded-lg bg-gradient-to-r from-[#aa771c] via-[#ffd700] to-[#b38728] text-black font-bold text-sm tracking-wider uppercase shadow-lg hover:brightness-110 transition-all cursor-pointer mt-2"
            >
              Masuk Panel Kelola Tamu
            </button>
          </form>
        </div>
      ) : (
        /* Authenticated Dashboard */
        <div className="relative w-full max-w-4xl bg-[#14151a] border-2 border-[#d4af37] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
          
          {/* Header Ribbon */}
          <div className="bg-gradient-to-r from-[#1c1b17] via-[#2c2615] to-[#1c1b17] border-b border-[#d4af37]/50 p-4 sm:p-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-[#d4af37]/20 border border-[#d4af37]/60">
                <Server className="w-5 h-5 text-[#ffd700]" />
              </div>
              <div>
                <h3 className="font-cinzel text-base sm:text-xl font-bold text-white tracking-wide">
                  Panel Kelola Tamu Undangan
                </h3>
                <p className="text-xs text-[#ffd700]/90">
                  Login sebagai: <span className="font-mono text-white">admin@gmail.com</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onRefreshGuests}
                className="p-2 rounded-lg bg-black/40 hover:bg-[#d4af37]/20 text-[#ffd700] border border-[#d4af37]/40 transition-colors"
                title="Refresh Data dari Server"
              >
                <RefreshCw className="w-4 h-4" />
              </button>

              <button
                onClick={handleLogout}
                className="px-2.5 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Keluar dari Panel Admin"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Keluar</span>
              </button>

              <button
                onClick={onClose}
                className="p-2 rounded-lg bg-black/40 hover:bg-stone-800 text-stone-300 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Navigation Tabs (Only 2 tabs: Daftar Tamu & Tambah Masal) */}
          <div className="flex items-center border-b border-stone-800 bg-black/40 px-4 pt-2 gap-2 text-xs sm:text-sm font-semibold">
            <button
              onClick={() => setActiveTab('guests')}
              className={`px-4 py-2.5 rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
                activeTab === 'guests'
                  ? 'border-[#ffd700] text-[#ffd700] bg-[#1a1b22]'
                  : 'border-transparent text-stone-400 hover:text-white'
              }`}
            >
              <span>Daftar Tamu ({guests.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('batch')}
              className={`px-4 py-2.5 rounded-t-lg transition-all border-b-2 flex items-center gap-2 ${
                activeTab === 'batch'
                  ? 'border-[#ffd700] text-[#ffd700] bg-[#1a1b22]'
                  : 'border-transparent text-stone-400 hover:text-white'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Tambah Masal (Batch)</span>
            </button>
          </div>

          {/* Tab 1: Guest List & Single Add */}
          {activeTab === 'guests' && (
            <div className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1">
              
              {/* Quick Add Form */}
              <form onSubmit={handleAddSingle} className="bg-black/50 border border-[#d4af37]/40 rounded-xl p-3 sm:p-4 grid grid-cols-1 sm:grid-cols-12 gap-2.5">
                <div className="sm:col-span-7">
                  <input
                    type="text"
                    required
                    placeholder="Nama Lengkap Tamu (contoh: Bpk Kolonel Laut...)"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-stone-900 border border-stone-700 text-white text-xs sm:text-sm focus:outline-none focus:border-[#ffd700]"
                  />
                </div>

                <div className="sm:col-span-3">
                  <input
                    type="text"
                    placeholder="Peran / Kategori"
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-stone-900 border border-stone-700 text-white text-xs sm:text-sm focus:outline-none focus:border-[#ffd700]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full h-full py-2.5 px-3 rounded-lg bg-gradient-to-r from-[#aa771c] to-[#d4af37] text-black font-bold text-xs sm:text-sm hover:brightness-110 flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Tambah</span>
                  </button>
                </div>
              </form>

              {/* Filter & Batch Actions */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type="text"
                    placeholder="Cari nama tamu..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2 rounded-lg bg-black/60 border border-stone-700 text-white text-xs sm:text-sm focus:outline-none focus:border-[#ffd700]"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopyAll}
                    className="px-3 py-2 rounded-lg border border-[#d4af37]/50 bg-[#d4af37]/15 hover:bg-[#d4af37]/30 text-[#ffd700] text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    {allCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Tersalin!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Salin Semua ({guests.length})</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={handleExportCsv}
                    className="px-3 py-2 rounded-lg border border-stone-700 bg-stone-900 hover:bg-stone-800 text-stone-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Ekspor CSV</span>
                  </button>
                </div>
              </div>

              {/* Guest Table / List */}
              <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
                {filteredGuests.map((guest, idx) => (
                  <div
                    key={guest.id}
                    className="p-3.5 rounded-xl bg-black/60 border border-stone-800 hover:border-[#d4af37]/60 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-[#d4af37] font-bold">
                          #{idx + 1}
                        </span>
                        <span className="font-bold text-sm sm:text-base text-white truncate">
                          {guest.name}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-stone-800 text-stone-300">
                          {guest.role || 'Tamu Undangan'}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-400 truncate mt-1 font-mono">
                        {getGuestUrl(guest)}
                      </p>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {/* WhatsApp */}
                      <button
                        type="button"
                        onClick={() => handleShareWhatsApp(guest)}
                        title="Kirim Pesan WhatsApp"
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-850 text-emerald-300 border border-emerald-700/60 flex items-center gap-1 text-xs cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                        <span>WhatsApp</span>
                      </button>

                      {/* Copy Link */}
                      <button
                        type="button"
                        onClick={() => handleCopyLink(guest)}
                        title="Salin Tautan Undangan"
                        className="px-2.5 py-1.5 rounded-lg bg-stone-900 hover:bg-stone-850 text-stone-200 border border-stone-700 flex items-center gap-1 text-xs cursor-pointer"
                      >
                        {copiedId === guest.id ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400 font-semibold">Tersalin!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-[#ffd700]" />
                            <span>Salin Link</span>
                          </>
                        )}
                      </button>

                      {/* QR Code */}
                      <button
                        type="button"
                        onClick={() => handleShowQr(guest)}
                        title="Tampilkan QR Code"
                        className="p-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700 cursor-pointer"
                      >
                        <QrCode className="w-3.5 h-3.5 text-[#ffd700]" />
                      </button>

                      {/* Preview */}
                      <button
                        type="button"
                        onClick={() => {
                          onSelectGuest(guest);
                          onClose();
                        }}
                        title="Lihat Pratinjau Undangan"
                        className="p-1.5 rounded-lg bg-[#aa771c]/30 hover:bg-[#aa771c]/60 text-[#ffd700] border border-[#d4af37]/40 cursor-pointer"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>

                      {/* Delete */}
                      <button
                        type="button"
                        onClick={() => handleDelete(guest.id, guest.name)}
                        title="Hapus Tamu"
                        className="p-1.5 rounded-lg hover:bg-rose-950/60 text-stone-500 hover:text-rose-400 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}

                {filteredGuests.length === 0 && (
                  <div className="text-center py-10 text-stone-400 text-sm">
                    Tidak ada tamu yang cocok dengan pencarian.
                  </div>
                )}
              </div>

            </div>
          )}

          {/* Tab 2: Batch Add */}
          {activeTab === 'batch' && (
            <div className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1">
              <div className="bg-black/40 border border-[#d4af37]/30 rounded-xl p-4">
                <h4 className="font-bold text-white text-sm sm:text-base mb-1">
                  Tambah Banyak Tamu Sekaligus (Batch Import)
                </h4>
                <p className="text-xs text-stone-300 mb-3">
                  Ketik atau salin daftar nama tamu (1 nama per baris). Sistem backend akan otomatis membuat ID, slug, dan tautan unik untuk masing-masing tamu.
                </p>

                <form onSubmit={handleBatchSubmit} className="space-y-3">
                  <textarea
                    rows={8}
                    required
                    placeholder={`Contoh:\nBpk Irjen Pol Rudy Heriyanto\nBpk Walikota Serang\nIbu Hj. Siti Aisyah\nBpk Letkol Infantri Ahmad`}
                    value={batchText}
                    onChange={(e) => setBatchText(e.target.value)}
                    className="w-full p-3 bg-stone-950 border border-stone-700 rounded-lg text-white font-mono text-xs focus:outline-none focus:border-[#ffd700]"
                  />

                  <div className="flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setBatchText('')}
                      className="px-4 py-2 rounded-lg bg-stone-900 text-stone-300 text-xs hover:bg-stone-800"
                    >
                      Kosongkan
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting || !batchText.trim()}
                      className="px-5 py-2 rounded-lg bg-gradient-to-r from-[#aa771c] to-[#d4af37] text-black font-bold text-xs hover:brightness-110 flex items-center gap-1.5 disabled:opacity-50"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Impor Sekarang</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="bg-black/70 border-t border-stone-800 p-3.5 flex items-center justify-between text-xs text-stone-400">
            <span>Sistem Undangan Online • Total Tamu: {guests.length}</span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-white font-semibold"
            >
              Tutup Panel
            </button>
          </div>

        </div>
      )}

      {/* QR Code Modal */}
      {qrModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/95 p-4">
          <div className="bg-[#181920] border-2 border-[#d4af37] rounded-2xl p-6 max-w-sm w-full text-center shadow-2xl relative">
            <button
              onClick={() => setQrModal(null)}
              className="absolute top-3 right-3 p-1 text-stone-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <h4 className="font-cinzel text-lg font-bold text-[#ffd700] mb-1">
              QR Code Undangan
            </h4>
            <p className="text-xs text-white font-medium mb-4">
              {qrModal.guest.name}
            </p>
            <div className="bg-white p-3 rounded-xl inline-block shadow-lg mx-auto">
              <img
                src={qrModal.qrUrl}
                alt={`QR Code ${qrModal.guest.name}`}
                className="w-56 h-56 mx-auto object-contain"
              />
            </div>
            <a
              href={qrModal.qrUrl}
              download={`QR-Undangan-${qrModal.guest.name.replace(/\s+/g, '_')}.png`}
              className="inline-flex items-center gap-2 mt-4 px-4 py-2 rounded-lg bg-gradient-to-r from-[#aa771c] to-[#d4af37] text-black font-semibold text-xs hover:brightness-110"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh Gambar QR Code</span>
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
