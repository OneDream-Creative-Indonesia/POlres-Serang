import React from 'react';
import { Home, Calendar, ListOrdered, MapPin } from 'lucide-react';

interface BottomNavBarProps {
  activeSection: string;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({ activeSection }) => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else if (id === 'top') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-gradient-to-t from-black via-[#111217] to-[#16171e]/95 border-t border-[#d4af37]/40 backdrop-blur-lg px-4 py-2.5">
      <div className="max-w-sm mx-auto flex items-center justify-around">
        
        <button
          onClick={() => scrollTo('top')}
          className={`flex flex-col items-center gap-1 p-1 text-[11px] font-medium transition-colors cursor-pointer ${
            activeSection === 'top' ? 'text-[#ffd700]' : 'text-stone-400 hover:text-white'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>Sampul</span>
        </button>

        <button
          onClick={() => scrollTo('acara')}
          className={`flex flex-col items-center gap-1 p-1 text-[11px] font-medium transition-colors cursor-pointer ${
            activeSection === 'acara' ? 'text-[#ffd700]' : 'text-stone-400 hover:text-white'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Acara</span>
        </button>

        <button
          onClick={() => scrollTo('rundown')}
          className={`flex flex-col items-center gap-1 p-1 text-[11px] font-medium transition-colors cursor-pointer ${
            activeSection === 'rundown' ? 'text-[#ffd700]' : 'text-stone-400 hover:text-white'
          }`}
        >
          <ListOrdered className="w-4 h-4" />
          <span>Susunan</span>
        </button>

        <button
          onClick={() => scrollTo('lokasi')}
          className={`flex flex-col items-center gap-1 p-1 text-[11px] font-medium transition-colors cursor-pointer ${
            activeSection === 'lokasi' ? 'text-[#ffd700]' : 'text-stone-400 hover:text-white'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Lokasi</span>
        </button>

      </div>
    </nav>
  );
};
