<?php
/**
 * Hostinger PHP Backend Alternative for Guest List Management
 * Save this file on Hostinger: public_html/api/guests.php
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$dataFile = __DIR__ . '/guests.json';

// Initialize data file with initial VIP guests if not exists
if (!file_exists($dataFile)) {
    $initialGuests = [
        ["id" => "guest_1", "name" => "Ibu Vita", "role" => "Tamu Kehormatan", "slug" => "ibu-vita", "createdAt" => date('c')],
        ["id" => "guest_2", "name" => "Bpk Fardhan Fauzan Nurfaizi & Ibu Fika", "role" => "Tamu Kehormatan", "slug" => "bpk-fardhan-fauzan-nurfaizi-ibu-fika", "createdAt" => date('c')],
        ["id" => "guest_3", "name" => "Bpk Aditya Argobi", "role" => "Tamu Kehormatan", "slug" => "bpk-aditya-argobi", "createdAt" => date('c')],
        ["id" => "guest_4", "name" => "Bpk Dharmawan", "role" => "Tamu Kehormatan", "slug" => "bpk-dharmawan", "createdAt" => date('c')],
        ["id" => "guest_5", "name" => "Ibu Indira", "role" => "Tamu Kehormatan", "slug" => "ibu-indira", "createdAt" => date('c')],
        ["id" => "guest_6", "name" => "Ibu Raisha Syarfuan", "role" => "Tamu Kehormatan", "slug" => "ibu-raisha-syarfuan", "createdAt" => date('c')]
    ];
    file_put_contents($dataFile, json_encode($initialGuests, JSON_PRETTY_PRINT));
}

function getGuests($dataFile) {
    $json = file_get_contents($dataFile);
    return json_decode($json, true) ?: [];
}

function saveGuests($dataFile, $guests) {
    file_put_contents($dataFile, json_encode($guests, JSON_PRETTY_PRINT));
}

$method = $_SERVER['REQUEST_METHOD'];
$guests = getGuests($dataFile);

if ($method === 'GET') {
    echo json_encode($guests);
    exit();
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Batch import
    if (isset($input['names']) && is_array($input['names'])) {
        $added = [];
        foreach ($input['names'] as $item) {
            $name = is_string($item) ? trim($item) : trim($item['name'] ?? '');
            if ($name !== '') {
                $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
                $newGuest = [
                    "id" => "guest_" . round(microtime(true) * 1000) . "_" . rand(100, 999),
                    "name" => $name,
                    "role" => is_array($item) && isset($item['role']) ? $item['role'] : "Tamu Undangan",
                    "slug" => $slug,
                    "createdAt" => date('c')
                ];
                $guests[] = $newGuest;
                $added[] = $newGuest;
            }
        }
        saveGuests($dataFile, $guests);
        http_response_code(201);
        echo json_encode(["count" => count($added), "added" => $added]);
        exit();
    }

    $name = trim($input['name'] ?? '');
    if ($name === '') {
        http_response_code(400);
        echo json_encode(["error" => "Nama tamu wajib diisi"]);
        exit();
    }

    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
    $newGuest = [
        "id" => "guest_" . round(microtime(true) * 1000) . "_" . rand(100, 999),
        "name" => $name,
        "role" => trim($input['role'] ?? '') ?: "Tamu Undangan",
        "slug" => $slug,
        "createdAt" => date('c')
    ];

    array_unshift($guests, $newGuest);
    saveGuests($dataFile, $guests);

    http_response_code(201);
    echo json_encode($newGuest);
    exit();
}

if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    if (!$id) {
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? '';
    }

    $filtered = array_filter($guests, function($g) use ($id) {
        return $g['id'] !== $id;
    });

    saveGuests($dataFile, array_values($filtered));
    echo json_encode(["success" => true, "id" => $id]);
    exit();
}
